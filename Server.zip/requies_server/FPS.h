#pragma once
class FPS
{
protected:
	uint32 _lastTick = 0;
	uint32 _sumTick = 0;
};

